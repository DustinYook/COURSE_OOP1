#ifndef CALCULATOR_H
#define CALCULATOR_H
#include "Adder.h"
#include <iostream>
using namespace std;

/* Calculator class*/
class Calculator
{ 
public:
	void run();
};
#endif